export interface User {
  id: number | string
  name: string
  photo?: string
  professional?: string
}
